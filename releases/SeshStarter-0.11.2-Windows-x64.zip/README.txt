Sesh Starter - Windows public beta 0.11.2

Windows 10/11, 64-bit. No .NET SDK, Python or Homebrew required.

1. Extract the entire ZIP into a folder you can write to, for example:
   %LOCALAPPDATA%\SeshStarter
   Do not run from inside the ZIP, Program Files, or a read-only folder.
2. Open SeshStarter.exe. Keep App.xaml, Settings.xaml and assets next to it.
3. Import a beat. On first import the app downloads FFmpeg and verifies its
   pinned SHA-256 hash before installation. Allow time for this initial setup.
4. On first YouTube download the app also installs a verified Node runtime
   and yt-dlp. The first setup requires internet access. Try again if it fails.
   Existing tools are preserved. After setup, local audio analysis works offline.

Your history, settings and covers live in data next to the executable.
Do not delete data when installing a new version. Back up this folder if needed.
Audio files remain in their original locations. YouTube downloads default to
Downloads\Sesh Starter; change the destination in Settings.

Updates: a new version appears as an Update button when a signed release is
available. The app verifies the signature and archive hash, keeps a temporary
backup, replaces only app files, and restarts. It preserves data and tools.
Keep the name SeshStarter.exe. Run from a writable local folder.

This is a public beta. Report feedback to contact@seshstarter.com.
Updates are delivered through the signed Sesh Starter release feed.
The executable is not Authenticode-signed; Windows may show a publisher warning.
RSA update signatures protect updates and do not identify a publisher to Windows.

Test: import MP3/WAV/FLAC, play/pause/seek, half/double BPM, close/reopen,
history/search, and a public YouTube beat you have permission to download.
Half/double changes 140 to 70 or 280 BPM to match how you count the rhythm.
Key detection is an estimate; confirm against your DAW before recording.
Report Windows version, steps, screenshots and output\crash.log if present.

First-run setup and the release checklist were accepted in external Windows testing.
BPM and key are estimates; half/double tempo and ambiguous keys can occur.
